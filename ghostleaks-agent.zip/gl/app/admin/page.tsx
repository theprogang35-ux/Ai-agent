import { db } from "@/lib/supabase"; import AutoRefresh from "@/components/AutoRefresh";
export const dynamic = "force-dynamic";
export default async function Admin({ searchParams }: { searchParams: { q?: string; source?: string } }) {
  const s = (searchParams.q || "").replace(/[,()%]/g, "");
  let q = db().from("leads").select("*");
  if (searchParams.source) q = q.eq("source", searchParams.source);
  if (s) q = q.or(`name.ilike.%${s}%,email.ilike.%${s}%`);
  const { data } = await q.order("created_at", { ascending: false }).limit(500);
  return (<main className="min-h-screen bg-[#050507] p-8 text-zinc-200">
    <div className="mb-6 flex items-center gap-4"><h1 className="text-2xl font-semibold">Leads</h1><AutoRefresh />
      <form className="ml-auto flex gap-2"><input name="q" defaultValue={searchParams.q} placeholder="Search name / email" className="rounded-lg border border-white/10 bg-white/5 px-3 py-2 text-sm" />
        <select name="source" defaultValue={searchParams.source ?? ""} className="rounded-lg border border-white/10 bg-zinc-900 px-3 py-2 text-sm"><option value="">All sources</option>{["web", "whatsapp", "telegram", "meeting"].map(x => <option key={x}>{x}</option>)}</select>
        <button className="rounded-lg bg-white px-4 text-sm font-medium text-black">Filter</button></form></div>
    <div className="overflow-x-auto rounded-2xl border border-white/10 bg-white/[0.03]"><table className="w-full text-left text-sm">
      <thead className="text-xs uppercase text-zinc-500"><tr>{["Name", "Email", "Phone", "Product Asked", "Meeting Time", "Chat History", "Source", "Date"].map(h => <th key={h} className="p-3">{h}</th>)}</tr></thead>
      <tbody>{data?.map((l: any) => <tr key={l.id} className="border-t border-white/5 align-top"><td className="p-3">{l.name}</td><td className="p-3">{l.email}</td><td className="p-3">{l.phone}</td><td className="p-3">{l.product_asked}</td><td className="p-3">{l.meeting_time}</td>
        <td className="max-w-xs p-3"><details><summary className="cursor-pointer text-violet-400">{l.chat_history?.length ?? 0} msgs</summary>{l.chat_history?.map((m: any, i: number) => <p key={i} className="mt-1 text-xs text-zinc-400"><b>{m.role}:</b> {m.text}</p>)}</details></td>
        <td className="p-3">{l.source}</td><td className="whitespace-nowrap p-3">{new Date(l.created_at).toLocaleString()}</td></tr>)}</tbody></table></div></main>);
}
