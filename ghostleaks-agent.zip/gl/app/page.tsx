import FeatureCards from "@/components/FeatureCards";
export default function Home() { return (<main className="relative flex min-h-screen flex-col items-center justify-center overflow-hidden px-6 text-center">
  <div className="absolute -top-40 h-[500px] w-[700px] rounded-full bg-violet-600/20 blur-[120px]" />
  <p className="relative mb-4 rounded-full border border-white/10 bg-white/5 px-4 py-1 text-xs text-zinc-400">Self-hosted · White-label · Multi-tenant</p>
  <h1 className="relative max-w-3xl bg-gradient-to-b from-white to-zinc-500 bg-clip-text text-5xl font-bold tracking-tight text-transparent md:text-7xl">Know about the breach before attackers do.</h1>
  <p className="relative mt-6 max-w-xl text-zinc-400">Breach monitoring for MSPs, agencies and security teams. Ask our AI anything — answers come straight from the docs.</p><FeatureCards /></main>); }
