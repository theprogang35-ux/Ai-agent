import "./globals.css"; import ChatWidget from "@/components/ChatWidget";
export const metadata = { title: "GhostLeaks — Breach Monitoring", description: "Self-hosted, white-label breach monitoring." };
export default function L({ children }: { children: React.ReactNode }) { return <html lang="en"><body className="bg-[#050507] text-zinc-200 antialiased">{children}<ChatWidget /></body></html>; }
