import crypto from "crypto"; import { ask } from "@/lib/ask";
export async function GET(req: Request) {
  const q = new URL(req.url).searchParams;
  return q.get("hub.verify_token") === process.env.WA_VERIFY_TOKEN && process.env.WA_VERIFY_TOKEN ? new Response(q.get("hub.challenge")) : new Response("Forbidden", { status: 403 });
}
export async function POST(req: Request) {
  const raw = await req.text(), secret = process.env.WA_APP_SECRET;
  if (secret) {
    const sig = req.headers.get("x-hub-signature-256") || "", exp = "sha256=" + crypto.createHmac("sha256", secret).update(raw).digest("hex");
    if (sig.length !== exp.length || !crypto.timingSafeEqual(Buffer.from(sig), Buffer.from(exp))) return new Response("Forbidden", { status: 403 });
  }
  try {
    const m = JSON.parse(raw)?.entry?.[0]?.changes?.[0]?.value?.messages?.[0];
    if (m?.type === "text" && m.text?.body) {
      const text = await ask(String(m.text.body).slice(0, 1000), `wa-${m.from}`, "whatsapp");
      await fetch(`https://graph.facebook.com/v19.0/${process.env.WA_PHONE_ID}/messages`, { method: "POST", headers: { Authorization: `Bearer ${process.env.WA_TOKEN}`, "Content-Type": "application/json" },
        body: JSON.stringify({ messaging_product: "whatsapp", to: m.from, text: { body: text } }) });
    }
  } catch (e) { console.error(e); }
  return Response.json({ ok: true }); // always 200 so Meta doesn't retry-storm
}
