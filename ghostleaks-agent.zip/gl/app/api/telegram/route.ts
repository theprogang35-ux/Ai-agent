import { ask } from "@/lib/ask";
export async function POST(req: Request) {
  const s = process.env.TG_WEBHOOK_SECRET;
  if (s && req.headers.get("x-telegram-bot-api-secret-token") !== s) return new Response("Forbidden", { status: 403 });
  try {
    const msg = (await req.json())?.message;
    if (msg?.text) {
      const text = await ask(String(msg.text).slice(0, 1000), `tg-${msg.chat.id}`, "telegram");
      await fetch(`https://api.telegram.org/bot${process.env.TG_BOT_TOKEN}/sendMessage`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ chat_id: msg.chat.id, text }) });
    }
  } catch (e) { console.error(e); }
  return Response.json({ ok: true });
}
