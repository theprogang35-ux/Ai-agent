import { limited, clientIp } from "@/lib/rl"; import { saveLead } from "@/lib/lead";
export async function POST(req: Request) {
  if (limited(`lead-${clientIp(req)}`, 5)) return Response.json({ error: "Too many requests" }, { status: 429 });
  const r = await saveLead(await req.json().catch(() => ({})));
  return Response.json(r.body, { status: r.status });
}
