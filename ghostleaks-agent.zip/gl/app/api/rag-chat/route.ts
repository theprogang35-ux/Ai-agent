import { search } from "@/lib/search"; import { limited, clientIp } from "@/lib/rl"; import { polish } from "@/lib/gemini";
export async function POST(req: Request) {
  const internal = !!process.env.INTERNAL_SECRET && req.headers.get("x-internal-secret") === process.env.INTERNAL_SECRET;
  const key = internal ? `i-${req.headers.get("x-rate-key") ?? "x"}` : clientIp(req);
  if (limited(key, 10)) return Response.json({ error: "Rate limit: 10 requests/min" }, { status: 429 });
  const { query } = await req.json().catch(() => ({}));
  if (!query || typeof query !== "string" || query.length > 1000) return Response.json({ error: "Invalid query" }, { status: 400 });
  const r = search(query); // local BM25 over data/kb.json — works with no API
  if (r.sources.length && r.ctx) { const g = await polish(query, r.ctx); if (g) return Response.json(g.startsWith("This information is not") ? { answer: g, sources: [] } : { answer: g, sources: r.sources }); }
  return Response.json({ answer: r.answer, sources: r.sources });
}
