"use client";
const CARDS = [["🔎 Multi-provider", "Multiple breach providers"], ["🏢 Multi-tenant", "Is it multi-tenant?"], ["🔐 Verified domains", "Domain monitoring workflow"], ["💳 Stripe billing", "Stripe billing"]];
export default function FeatureCards() {
  return <div className="relative mt-12 grid w-full max-w-4xl gap-4 sm:grid-cols-2 lg:grid-cols-4">{CARDS.map(([t, q]) =>
    <button key={t} onClick={() => window.dispatchEvent(new CustomEvent("gl-ask", { detail: q }))} className="rounded-2xl border border-white/10 bg-white/[0.04] p-5 text-left transition hover:border-violet-400/50 hover:bg-white/10"><p className="font-semibold text-white">{t}</p><p className="mt-1 text-xs text-zinc-400">Click to ask →</p></button>)}</div>;
}
