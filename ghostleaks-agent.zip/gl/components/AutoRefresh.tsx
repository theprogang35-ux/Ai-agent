"use client"; import { useRouter } from "next/navigation"; import { useEffect } from "react";
export default function AutoRefresh() { const r = useRouter(); useEffect(() => { const t = setInterval(() => r.refresh(), 8000); return () => clearInterval(t); }, [r]); return <span className="text-xs text-emerald-400">● live</span>; }
