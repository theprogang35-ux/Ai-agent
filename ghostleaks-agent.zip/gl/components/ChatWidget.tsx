"use client";
import { useState, useRef, useEffect } from "react";
const OWNER = process.env.NEXT_PUBLIC_OWNER_EMAIL || "ritdmdkkd@gmail.com";
const CHIPS = ["What is the product?", "Domain monitoring workflow", "Deployment steps with Docker", "REST API endpoints", "Stripe billing", "Is it multi-tenant?"];
type Msg = { role: "user" | "bot"; text: string; sources?: string[]; nf?: boolean; q?: string };
export default function ChatWidget() {
  const [open, setOpen] = useState(false), [view, setView] = useState<"menu" | "chat" | "book" | "email" | "soon">("menu");
  const [msgs, setMsgs] = useState<Msg[]>([{ role: "bot", text: "Hi! Ask me anything about GhostLeaks." }]);
  const [input, setInput] = useState(""), [busy, setBusy] = useState(false), [email, setEmail] = useState(""), [done, setDone] = useState(false), [err, setErr] = useState(""), [fwd, setFwd] = useState<string | null>(null), [name, setName] = useState(""), [phone, setPhone] = useState(""), [soon, setSoon] = useState("");
  const end = useRef<HTMLDivElement>(null); useEffect(() => end.current?.scrollIntoView({ behavior: "smooth" }), [msgs]);
  useEffect(() => { const h = (e: any) => { setOpen(true); setView("chat"); send(e.detail); }; window.addEventListener("gl-ask", h); return () => window.removeEventListener("gl-ask", h); });
  const cal = process.env.NEXT_PUBLIC_CAL_LINK;
  async function send(override?: string) {
    const q = (override ?? input).trim(); if (!q || busy) return; setInput(""); setBusy(true); setMsgs(m => [...m, { role: "user", text: q }]);
    try { const r = await fetch("/api/rag-chat", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ query: q }) }); const j = await r.json();
      setMsgs(m => [...m, { role: "bot", text: j.answer ?? j.error ?? "Something went wrong.", sources: j.sources, q, nf: !j.sources?.length && String(j.answer ?? "").startsWith("This information is not") }]);
    } catch { setMsgs(m => [...m, { role: "bot", text: "Network error. Try again." }]); } setBusy(false);
  }
  async function lead() {
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email)) return setErr("Enter a valid email address");
    const r = await fetch("/api/leads", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ email, name, phone, forwarded: !!fwd, source: "web", product_asked: fwd ?? msgs.filter(m => m.role === "user").map(m => m.text).pop(), chat_history: msgs }) });
    r.ok ? (setDone(true), setErr("")) : setErr("Could not save. Try again.");
  }
  const btn = "w-full rounded-xl border border-white/10 bg-white/5 px-4 py-3 text-left text-sm text-white transition hover:border-violet-400/50 hover:bg-white/10";
  const inp = "w-full rounded-xl bg-white/5 px-4 py-2.5 text-sm text-white outline-none ring-1 ring-white/10 focus:ring-violet-400";
  return (<div className="fixed bottom-5 right-5 z-50">
    <div className={`mb-3 flex h-[540px] w-[380px] max-w-[calc(100vw-2.5rem)] origin-bottom-right flex-col overflow-hidden rounded-2xl border border-white/10 bg-zinc-950/70 shadow-2xl shadow-violet-900/30 backdrop-blur-2xl transition-all duration-300 ${open ? "scale-100 opacity-100" : "invisible pointer-events-none scale-90 opacity-0"}`}>
      <div className="flex items-center gap-3 bg-gradient-to-r from-violet-600/30 to-cyan-500/20 p-4"><div className="h-9 w-9 rounded-full bg-gradient-to-br from-violet-500 to-cyan-400" /><div className="flex-1"><p className="text-sm font-semibold text-white">GhostLeaks AI</p><p className="text-xs text-emerald-400">● Online</p></div>
        </div>
      {view === "menu" && <div className="space-y-3 p-4"><p className="text-sm text-zinc-400">How can we help?</p>
        <button className={btn} onClick={() => setView("chat")}>💬 Product QnA</button>
        <button className={btn} onClick={() => setView("book")}>📅 Book Meeting via Cal.com</button>
        <button className={btn} onClick={() => { setFwd(null); setView("email"); }}>🙋 Talk to Human</button></div>}
      {view === "chat" && <><div className="flex-1 space-y-3 overflow-y-auto p-4">{msgs.map((m, i) => <div key={i} className={m.role === "user" ? "flex justify-end" : ""}><div className={`max-w-[85%] rounded-2xl px-3.5 py-2 text-sm ${m.role === "user" ? "bg-white text-black" : "bg-zinc-900 text-zinc-100"}`}>{m.text}
        
        {m.nf && <button onClick={() => { setFwd(m.q ?? null); setView("email"); }} className="mt-2 block rounded-lg bg-gradient-to-r from-violet-500 to-cyan-400 px-3 py-1.5 text-xs font-semibold text-black">📨 Forward this question to our team</button>}</div></div>)}{busy && <p className="animate-pulse text-xs text-zinc-500">Thinking…</p>}<div ref={end} /></div>
        <div className="flex gap-2 overflow-x-auto border-t border-white/10 px-3 pt-2">{CHIPS.map(c => <button key={c} onClick={() => send(c)} className="shrink-0 rounded-full border border-white/10 bg-white/5 px-3 py-1 text-xs text-zinc-300 transition hover:border-violet-400/50 hover:text-white">{c}</button>)}</div><div className="p-3"><input value={input} onChange={e => setInput(e.target.value)} onKeyDown={e => e.key === "Enter" && send()} placeholder="Ask about GhostLeaks…" className={inp} /></div></>}
      {view === "book" && (cal ? <iframe src={`https://cal.com/${cal}?embed=true&theme=dark`} className="flex-1 border-0" /> : <p className="p-4 text-sm text-zinc-400">Set NEXT_PUBLIC_CAL_LINK to enable booking.</p>)}
      {view === "email" && (() => { const su = encodeURIComponent("GhostLeaks request"), bd = encodeURIComponent(fwd ? fwd + "\n\n" : ""); return <div className="space-y-3 p-4">
        <p className="text-sm text-zinc-400">{fwd ? "This isn't in our documentation. Send it to our team directly:" : "Reach our team directly by email:"}</p>
        {fwd && <p className="rounded-lg bg-white/5 p-2 text-xs text-zinc-300">“{fwd}”</p>}
        <a href={`mailto:${OWNER}?subject=${su}&body=${bd}`} className="block w-full rounded-xl bg-gradient-to-r from-violet-500 to-cyan-400 py-2.5 text-center text-sm font-semibold text-black">📧 Forward your request — Open Gmail</a>
        <a href={`https://mail.google.com/mail/?view=cm&fs=1&to=${OWNER}&su=${su}&body=${bd}`} target="_blank" rel="noopener noreferrer" className="block text-center text-xs text-violet-300 hover:underline">or open Gmail in browser</a>
        <p className="text-xs text-zinc-500">Opens your mail app addressed to {OWNER}.</p></div>; })()}
    </div>
    <button onClick={() => { if (open) setView("menu"); setOpen(o => !o); }} aria-label="Chat" className="ml-auto flex h-14 w-14 items-center justify-center rounded-full bg-gradient-to-br from-violet-500 to-cyan-400 text-2xl shadow-2xl shadow-violet-500/40 transition hover:scale-105">{open ? "×" : "💬"}</button></div>);
}
