import { NextResponse, type NextRequest } from "next/server";
export const config = { matcher: ["/admin/:path*"] };
export function middleware(req: NextRequest) {
  const h = req.headers.get("authorization") || "";
  if (h.startsWith("Basic ") && atob(h.slice(6)) === `${process.env.ADMIN_USER}:${process.env.ADMIN_PASSWORD}` && process.env.ADMIN_PASSWORD) return NextResponse.next();
  return new NextResponse("Auth required", { status: 401, headers: { "WWW-Authenticate": 'Basic realm="admin"' } });
}
