import nodemailer from "nodemailer";
export async function sendMail(to: string, subject: string, text: string, replyTo?: string) {
  const user = process.env.MAIL_USERNAME, pass = process.env.MAIL_PASSWORD; if (!user || !pass) return;
  const port = Number(process.env.SMTP_PORT || 465);
  const t = nodemailer.createTransport({ host: process.env.SMTP_HOST || "smtp.gmail.com", port, secure: port === 465, auth: { user, pass } });
  await t.sendMail({ from: `"GhostLeaks AI" <${user}>`, to, subject, text, replyTo });
}
