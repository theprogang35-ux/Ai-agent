const hits = new Map<string, number[]>();
export function limited(key: string, max: number, windowMs = 60000) {
  const now = Date.now();
  if (hits.size > 5000) for (const [k, v] of hits) if (now - v[v.length - 1] > windowMs) hits.delete(k);
  const r = (hits.get(key) || []).filter(t => now - t < windowMs);
  if (r.length >= max) { hits.set(key, r); return true; }
  hits.set(key, [...r, now]); return false;
}
export const clientIp = (req: Request) => (req.headers.get("x-forwarded-for") || "local").split(",")[0].trim();
