import { db } from "@/lib/supabase"; import { sendMail } from "@/lib/mail";
const RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
const str = (v: unknown, n: number) => (typeof v === "string" && v.trim() ? v.trim().slice(0, n) : null);
export async function saveLead(b: any): Promise<{ status: number; body: any }> {
  const email = str(b.email, 254)?.toLowerCase();
  if (!email || !RE.test(email)) return { status: 400, body: { error: "Invalid email" } };
  const fwd = b.forwarded === true, q = str(b.product_asked, 500);
  const hist = Array.isArray(b.chat_history) ? b.chat_history.slice(-50).map((m: any) => ({ role: String(m?.role).slice(0, 10), text: String(m?.text ?? "").slice(0, 2000) })) : [];
  const lead = { name: str(b.name, 120), email, phone: str(b.phone, 30), product_asked: ((fwd ? "[Forwarded] " : "") + (q ?? "")) || null, meeting_time: str(b.meeting_time, 100), chat_history: hist,
    source: ["web", "whatsapp", "telegram", "meeting"].includes(b.source) ? b.source : "web" };
  const { error } = await db().from("leads").insert(lead);
  if (error) { console.error(error); return { status: 500, body: { error: "Save failed" } }; }
  const owner = process.env.OWNER_EMAIL || "ritdmdkkd@gmail.com";
  const summary = `${fwd ? "Question not found in documentation" : "New lead"}\nFrom: ${lead.name ?? "-"} <${email}>\nPhone: ${lead.phone ?? "-"}\nVia: ${lead.source}\nQuestion: ${q ?? "-"}\n\nChat:\n${hist.map((m: any) => `${m.role}: ${m.text}`).join("\n")}`;
  const jobs: Promise<unknown>[] = [sendMail(owner, fwd ? "Forwarded question from GhostLeaks AI" : "New GhostLeaks lead", summary, email)];
  if (fwd) jobs.push(sendMail(email, "We received your question", `Hi,\n\nThanks for your question:\n"${q}"\n\nIt isn't covered in our documentation, so our team will reply to you personally.\n\n— GhostLeaks`));
  if (process.env.N8N_WEBHOOK_URL) jobs.push(fetch(process.env.N8N_WEBHOOK_URL, { method: "POST", signal: AbortSignal.timeout(5000), headers: { "Content-Type": "application/json" }, body: JSON.stringify(lead) }));
  if (process.env.WA_PHONE_ID && process.env.WA_TOKEN && process.env.CLIENT_WA_NUMBER)
    jobs.push(fetch(`https://graph.facebook.com/v19.0/${process.env.WA_PHONE_ID}/messages`, { method: "POST", signal: AbortSignal.timeout(5000), headers: { Authorization: `Bearer ${process.env.WA_TOKEN}`, "Content-Type": "application/json" },
      body: JSON.stringify({ messaging_product: "whatsapp", to: process.env.CLIENT_WA_NUMBER, type: "text", text: { body: summary.slice(0, 1000) } }) }));
  if (process.env.TG_BOT_TOKEN && process.env.TG_OWNER_CHAT_ID)
    jobs.push(fetch(`https://api.telegram.org/bot${process.env.TG_BOT_TOKEN}/sendMessage`, { method: "POST", signal: AbortSignal.timeout(5000), headers: { "Content-Type": "application/json" }, body: JSON.stringify({ chat_id: process.env.TG_OWNER_CHAT_ID, text: summary.slice(0, 3500) }) }));
  (await Promise.allSettled(jobs)).forEach(r => r.status === "rejected" && console.error(r.reason));
  return { status: 200, body: { ok: true } };
}
