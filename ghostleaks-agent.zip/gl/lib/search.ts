// @ts-nocheck
import KB from "@/data/kb.json";
const SW=new Set("a an the and or of to in on for with is are was be by as at it this that from how do does what which can i you your my we our not no if so than then there their them they he she his her its into over about work works offer use".split(" ")),stem=w=>w.length>4?w.replace(/(ing|ed|es|s)$/,""):w,tok=s=>(s.toLowerCase().match(/[a-z0-9_]+/g)||[]).filter(w=>w.length>1&&!SW.has(w)).map(stem);
const D=KB.map(c=>{const t=tok(c.t),tf=new Map;t.forEach(w=>tf.set(w,(tf.get(w)||0)+1));return{...c,tf,len:t.length}}),DF=new Map;D.forEach(d=>d.tf.forEach((_,w)=>DF.set(w,(DF.get(w)||0)+1)));const AV=D.reduce((a,d)=>a+d.len,0)/D.length;
function S(q){const ov=KB.find(c=>c.o);if(ov&&/(what('?s| is| are)?\s+(the\s+|your\s+|this\s+)?(product|ghostleaks|service)|what\s+(do|are)\s+(you|we)\s+(sell|selling|offer)|tell me about|what does ghostleaks do|about ghostleaks)/i.test(q))return{answer:ov.t,sources:["Page "+ov.p]};const NO={answer:"This information is not in the provided documentation",sources:[]},qt=[...new Set(tok(q))];
if(!qt.length)return/[a-z]/i.test(q)?NO:{answer:"Please ask your question in English — the documentation is in English.",sources:[]};
const N=D.length,sc=D.map(d=>{let s=0,m=0;for(const w of qt){const f=d.tf.get(w);if(!f)continue;m++;const n=DF.get(w);s+=Math.log(1+(N-n+.5)/(n+.5))*f*2.2/(f+1.2*(.25+.75*d.len/AV))}return{d,s:s*(m/qt.length)**2,m}}).filter(x=>x.m/qt.length>.5).sort((a,b)=>b.s-a.s);
if(!sc.length)return NO;const top=sc.slice(0,3),ss=top.flatMap((x,r)=>x.d.t.split(/(?<=[.!?])\s+/).map((s,i)=>({s,i,r,k:qt.filter(w=>tok(s).includes(w)).length})));
let pk=ss.filter(x=>x.k>0).sort((a,b)=>b.k-a.k||a.r-b.r).slice(0,3).sort((a,b)=>a.r-b.r||a.i-b.i);if(!pk.length)pk=ss.slice(0,2);
return{answer:pk.map(x=>x.s).join(" "),sources:[...new Set(top.map(x=>typeof x.d.p=="number"?"Page "+x.d.p:x.d.p))],ctx:top.map(x=>x.d.t).join("\n---\n")}}

export const search = S;
