import { saveLead } from "@/lib/lead";
const FW = /^forward\s+(\S+@\S+\.\S{2,})\s+([\s\S]{3,})$/i;
export async function ask(query: string, rateKey: string, channel = "whatsapp") {
  const f = query.match(FW);
  if (f) { const r = await saveLead({ email: f[1], product_asked: f[2], forwarded: true, source: channel, chat_history: [{ role: "user", text: f[2] }] }); return r.status === 200 ? "✅ Forwarded to our team. We'll email you soon." : "Couldn't forward — please check the email address."; }
  try {
    const r = await fetch(`${process.env.APP_URL}/api/rag-chat`, { method: "POST", signal: AbortSignal.timeout(25000),
      headers: { "Content-Type": "application/json", "x-internal-secret": process.env.INTERNAL_SECRET || "", "x-rate-key": rateKey }, body: JSON.stringify({ query }) });
    const j = await r.json(); const t = String(j.answer ?? j.error ?? "Sorry, something went wrong.");
    const nf = t.startsWith("This information is not");
    return (nf ? `${t}.\n\nWant a human answer? Reply: FORWARD your@email.com your question` : t).slice(0, 4000);
  } catch { return "Sorry, I couldn't process that right now."; }
}
