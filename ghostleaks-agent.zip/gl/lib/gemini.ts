import { limited } from "@/lib/rl";
const SYS = "You are GhostLeaks AI. Answer ONLY from the provided context. If the context does not contain the answer, reply exactly: This information is not in the provided documentation. Never ask for email/password. Be concise and cite the page given in the context headers if present.";
const cache = new Map<string, string>();
// Optional polish. Returns null on ANY problem (no key, quota 429, timeout) so the caller falls back to the local PDF answer.
export async function polish(q: string, ctx: string): Promise<string | null> {
  const key = process.env.GEMINI_API_KEY; if (!key) return null;
  const ck = q.toLowerCase().trim(); if (cache.has(ck)) return cache.get(ck)!;
  if (limited("gemini-global", 10)) return null; // stay well under free-tier limits
  try {
    const r = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${process.env.GEMINI_MODEL || "gemini-2.5-flash"}:generateContent`, {
      method: "POST", signal: AbortSignal.timeout(8000), headers: { "Content-Type": "application/json", "x-goog-api-key": key },
      body: JSON.stringify({ systemInstruction: { parts: [{ text: SYS }] }, contents: [{ role: "user", parts: [{ text: `Context:\n${ctx}\n\nQuestion: ${q}` }] }], generationConfig: { temperature: 0, maxOutputTokens: 400 } }) });
    if (!r.ok) return null;
    const t = (await r.json())?.candidates?.[0]?.content?.parts?.[0]?.text?.trim();
    if (!t) return null; if (cache.size > 200) cache.clear(); cache.set(ck, t); return t;
  } catch { return null; }
}
