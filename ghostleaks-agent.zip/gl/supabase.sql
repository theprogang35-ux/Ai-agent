create table if not exists leads(id bigserial primary key, name text, email text not null, phone text, product_asked text, meeting_time text, chat_history jsonb, source text default 'web', created_at timestamptz default now());
alter table leads enable row level security; -- service key bypasses RLS; anon gets no access
