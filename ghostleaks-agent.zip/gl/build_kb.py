# python build_kb.py GhostLeaks_Complete_Documentation.pdf  ->  data/kb.json   (needs only: pip install pypdf)
import sys, re, json
from pypdf import PdfReader
FIX = [(r"RAZORPAY_KEY_ID\s*/\s*RAZORPAY_KEY_SECRET", "STRIPE_SECRET_KEY / STRIPE_WEBHOOK_SECRET"), (r"Payments:\s*Razorpay", "Payments: Stripe"),
 (r"Python\s+3\.9\s+or\s+higher", "Python 3.11"), (r"(?i)\bthree\s+/api/v1/\*\s+REST\s+endpoints", "two REST endpoints (check-email, check-password)"),
 (r"API access requires the account to be on a paid plan;\s*unpaid accounts receive 402\s+UPGRADE_REQUIRED\.", "API access has no payment gate (removed in v2.5.0).")]
CORR = ("Verified corrections: payments use Stripe Checkout and the /webhooks/stripe webhook (Razorpay was replaced in v1.0.2; older changelog mentions are history only). "
 "The app targets Python 3.11. Exactly two REST endpoints are CSRF-exempt: /api/v1/check-email and /api/v1/check-password. "
 "There is no 402 payment gate: since v2.5.0 email check, bulk scan, PDF reports and the REST API work for every account.")
out = [{"t": CORR, "p": "Corrections"}]; skipped = 0
for p, pg in enumerate(PdfReader(sys.argv[1]).pages, 1):
    t = (pg.extract_text() or "")
    for a, b in FIX: t = re.sub(a, b, t)
    w = t.split()
    if not w: continue
    tn = " ".join(t.split())
    if "sold as commercial source code" in tn and not any(c.get("o") for c in out):
        m = re.search(r"GhostLeaks Enterprise Edition is a self-hosted.*?(?=Feature List|\Z)", tn, re.S)
        if m: out.insert(0, {"t": " ".join(m.group(0).split()), "p": p, "o": 1})
    if p <= 4 and t.count(".") / len(w) < 0.015: skipped += 1; continue   # table-of-contents pages
    for i in range(0, len(w), 90):
        out.append({"t": " ".join(w[i:i + 110]), "p": p})
        if i + 110 >= len(w): break
json.dump(out, open("data/kb.json", "w"), ensure_ascii=False, separators=(",", ":"))
print(len(out), "chunks; skipped TOC pages:", skipped)
